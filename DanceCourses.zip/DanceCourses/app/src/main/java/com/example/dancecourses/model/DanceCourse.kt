package com.example.dancecourses.model

class DanceCourse {
    var courseId: Int = 0
    var courseName: String = ""
    var courseDate: String = ""
    var startTime: String = ""
    var endTime: String = ""
    var location: String = ""
    var level: String = ""

}