package com.example.dancecourses

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.example.dancecourses.database.DatabaseHelper
import com.example.dancecourses.model.DanceCourse

class AddCourse : AppCompatActivity() {

    lateinit var btn_save: Button
    lateinit var btn_del: Button
    lateinit var et_course_name: EditText
    lateinit var et_course_date: EditText
    lateinit var et_start_time: EditText
    lateinit var et_end_time: EditText
    lateinit var et_location: EditText
    lateinit var et_level: EditText

    var dbHandler: DatabaseHelper? = null
    var isEditMode: Boolean = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_course)

        btn_save = findViewById(R.id.btn_save)
        btn_del = findViewById(R.id.btn_del)
        et_course_name = findViewById(R.id.et_name)
        et_course_date = findViewById(R.id.et_date)
        et_start_time = findViewById(R.id.et_start_time)
        et_end_time = findViewById(R.id.et_end_time)
        et_location = findViewById(R.id.et_location)
        et_level = findViewById(R.id.et_level)

        dbHandler = DatabaseHelper(this)

        if (intent != null && intent.getStringExtra("Mode") == "E") {
            // update
            isEditMode = true
            btn_save.text = "Update"
            btn_del.visibility = View.VISIBLE

            val course: DanceCourse = dbHandler!!.getCourse(intent.getIntExtra("Id", 0))
            et_course_name.setText(course.courseName)
            et_course_date.setText(course.courseDate)
            et_start_time.setText(course.startTime)
            et_end_time.setText(course.endTime)
            et_location.setText(course.location)
            et_level.setText(course.level)

        } else {
            // insert new data
            isEditMode = false
            btn_save.text = "Save"
            btn_del.visibility = View.GONE
        }

        btn_save.setOnClickListener {
            var success: Boolean = false
            val course: DanceCourse = DanceCourse()
            if (isEditMode) {
                //update
                course.courseId = intent.getIntExtra("Id", 0)
                course.courseName = et_course_name.text.toString()
                course.courseDate = et_course_date.text.toString()
                course.startTime = et_start_time.text.toString()
                course.endTime = et_end_time.text.toString()
                course.location = et_location.text.toString()
                course.level = et_level.text.toString()

                success = dbHandler?.updateCourse(course) as Boolean
            } else {
                course.courseName = et_course_name.text.toString()
                course.courseDate = et_course_date.text.toString()
                course.startTime = et_start_time.text.toString()
                course.endTime = et_end_time.text.toString()
                course.location = et_location.text.toString()
                course.level = et_level.text.toString()

                success = dbHandler?.addCourse(course) as Boolean
            }

            if (success) {
                val i = Intent(applicationContext, MainActivity::class.java)
                startActivity(i)
                finish()
            } else {
                Toast.makeText(applicationContext, "Something went Wrong!", Toast.LENGTH_LONG)
                    .show()
            }
        }

        btn_del.setOnClickListener {
            val dialog = AlertDialog.Builder(this).setTitle("Info")
                .setMessage("Are you sure you want to delete this?")
                .setPositiveButton("YES", { dialog, i ->
                    val success =
                        dbHandler?.deleteCourse(intent.getIntExtra("Id", 0)) as Boolean
                    if (success)
                        finish()
                    dialog.dismiss()
                })
                .setNegativeButton("NO", { dialog, i ->
                    dialog.dismiss()
                })
            dialog.show()
        }
    }
}