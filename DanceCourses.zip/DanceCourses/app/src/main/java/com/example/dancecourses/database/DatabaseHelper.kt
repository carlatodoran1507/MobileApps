package com.example.dancecourses.database

import android.annotation.SuppressLint
import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import com.example.dancecourses.model.DanceCourse

class DatabaseHelper(context: Context) : SQLiteOpenHelper(context, DB_NAME, null, DB_VERSION) {

    companion object {
        private val DB_NAME = "courses"
        private val DB_VERSION = 1
        private val TABLE_NAME = "course_list"
        private val COURSE_ID = "course_id"
        private val COURSE_NAME = "course_name"
        private val COURSE_DATE = "course_date"
        private val START_TIME = "start_time"
        private val END_TIME = "end_time"
        private val LOCATION = "location"
        private val LEVEL = "level"
    }

    override fun onCreate(p0: SQLiteDatabase?) {
        val CREATE_TABLE = "CREATE TABLE $TABLE_NAME ($COURSE_ID INTEGER PRIMARY KEY, $COURSE_NAME TEXT," +
                "$COURSE_DATE TEXT, $START_TIME TEXT, $END_TIME TEXT, $LOCATION TEXT, $LEVEL TEXT)"
        p0?.execSQL(CREATE_TABLE)
    }

    override fun onUpgrade(p0: SQLiteDatabase?, p1: Int, p2: Int) {
        val DROP_TABLE = "DROP TABLE IF EXISTS $TABLE_NAME"
        p0?.execSQL(DROP_TABLE)
        onCreate(p0)
    }

    @SuppressLint("Range")
    fun getAllCourses(): List<DanceCourse> {
        val coursesList = ArrayList<DanceCourse>()
        val db = writableDatabase
        val selectAllQuery = "SELECT * FROM $TABLE_NAME"
        val cursor = db.rawQuery(selectAllQuery, null)
        if (cursor != null) {
            if (cursor.moveToFirst()) {
                do {
                    val course = DanceCourse()
                    course.courseId = Integer.parseInt(cursor.getString(cursor.getColumnIndex(COURSE_ID)))
                    course.courseName = cursor.getString(cursor.getColumnIndex(COURSE_NAME))
                    course.courseDate = cursor.getString(cursor.getColumnIndex(COURSE_DATE))
                    course.startTime = cursor.getString(cursor.getColumnIndex(START_TIME))
                    course.endTime = cursor.getString(cursor.getColumnIndex(END_TIME))
                    course.location = cursor.getString(cursor.getColumnIndex(LOCATION))
                    course.level = cursor.getString(cursor.getColumnIndex(LEVEL))
                    coursesList.add(course)
                } while (cursor.moveToNext())
            }
        }
        cursor.close()
        return coursesList
    }

    @SuppressLint("Range")
    fun getCourse(_id: Int): DanceCourse {
        val course = DanceCourse()
        val db = writableDatabase
        val selectQuery = "SELECT * FROM $TABLE_NAME WHERE $COURSE_ID = $_id"
        val cursor = db.rawQuery(selectQuery, null)

        cursor?.moveToFirst()
        course.courseId = Integer.parseInt(cursor.getString(cursor.getColumnIndex(COURSE_ID)))
        course.courseName = cursor.getString(cursor.getColumnIndex(COURSE_NAME))
        course.courseDate = cursor.getString(cursor.getColumnIndex(COURSE_DATE))
        course.startTime = cursor.getString(cursor.getColumnIndex(START_TIME))
        course.endTime = cursor.getString(cursor.getColumnIndex(END_TIME))
        course.location = cursor.getString(cursor.getColumnIndex(LOCATION))
        course.level = cursor.getString(cursor.getColumnIndex(LEVEL))
        cursor.close()
        return course
    }

    fun addCourse(course: DanceCourse): Boolean {
        val db = this.writableDatabase
        val values = ContentValues()
        values.put(COURSE_NAME, course.courseName)
        values.put(COURSE_DATE, course.courseDate)
        values.put(START_TIME, course.startTime)
        values.put(END_TIME, course.endTime)
        values.put(LOCATION, course.location)
        values.put(LEVEL, course.level)
        val _success = db.insert(TABLE_NAME, null, values)
        db.close()
        return (Integer.parseInt("$_success") != -1)
    }

    fun deleteCourse(_id: Int): Boolean {
        val db = this.writableDatabase
        val _success = db.delete(TABLE_NAME, COURSE_ID + "=?", arrayOf(_id.toString())).toLong()
        db.close()
        return Integer.parseInt("$_success") != -1
    }

    fun updateCourse(course: DanceCourse): Boolean {
        val db = this.writableDatabase
        val values = ContentValues()
        values.put(COURSE_NAME, course.courseName)
        values.put(COURSE_DATE, course.courseDate)
        values.put(START_TIME, course.startTime)
        values.put(END_TIME, course.endTime)
        values.put(LOCATION, course.location)
        values.put(LEVEL, course.level)
        val _success = db.update(TABLE_NAME, values, COURSE_ID + "=?", arrayOf(course.courseId.toString())).toLong()
        db.close()
        return Integer.parseInt("$_success") != -1
    }
}