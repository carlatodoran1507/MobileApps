package com.example.dancecourses

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.dancecourses.adapter.CourseListAdapter
import com.example.dancecourses.database.DatabaseHelper
import com.example.dancecourses.model.DanceCourse

class MainActivity : AppCompatActivity() {
    lateinit var recycler_course: RecyclerView
    lateinit var btn_add: Button
    var courseListAdapter: CourseListAdapter ?= null
    var dbHandler: DatabaseHelper ?= null
    var courseList: List<DanceCourse> = ArrayList<DanceCourse>()
    var linearLayoutManager: LinearLayoutManager ?= null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        recycler_course = findViewById(R.id.rv_list)
        btn_add = findViewById(R.id.bt_add_new_course) // din activity_main.xml

        dbHandler = DatabaseHelper(this)
        fetchList()

        btn_add.setOnClickListener {
            val index = Intent(applicationContext, AddCourse::class.java)
            startActivity(Intent(this, AddCourse::class.java))

//            startActivity(index)
        }
    }

    private fun fetchList() {
        courseList = dbHandler!!.getAllCourses()
        courseListAdapter = CourseListAdapter(courseList, applicationContext)
        linearLayoutManager = LinearLayoutManager(applicationContext)
        recycler_course.layoutManager = linearLayoutManager
        recycler_course.adapter = courseListAdapter
        courseListAdapter?.notifyDataSetChanged()

    }
}