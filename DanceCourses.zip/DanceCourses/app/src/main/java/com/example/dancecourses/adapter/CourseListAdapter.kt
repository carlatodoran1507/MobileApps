package com.example.dancecourses.adapter

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.dancecourses.AddCourse
import com.example.dancecourses.R
import com.example.dancecourses.model.DanceCourse

class CourseListAdapter(courseList: List<DanceCourse>, internal var context: Context) :
    RecyclerView.Adapter<CourseListAdapter.CourseViewHolder>() {

    internal var courseList: List<DanceCourse> = ArrayList()

    init {
        this.courseList = courseList
    }

    inner class CourseViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        var courseName: TextView = view.findViewById(R.id.txt_course_name)
        var courseDate: TextView = view.findViewById(R.id.txt_course_date)
        var startTime: TextView = view.findViewById(R.id.txt_start_time)
        var endTime: TextView = view.findViewById(R.id.txt_end_time)
        var location: TextView = view.findViewById(R.id.txt_location)
        var level: TextView = view.findViewById(R.id.txt_level)
        var btn_edit: Button = view.findViewById(R.id.btn_edit)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CourseViewHolder {
        val view = LayoutInflater.from(context).inflate(R.layout.recycler_course_list, parent, false)
        return CourseViewHolder(view)
    }

    override fun onBindViewHolder(holder: CourseViewHolder, position: Int) {
        val courses = courseList[position]
        holder.courseName.text = courses.courseName
        holder.courseDate.text = courses.courseDate
        holder.startTime.text = courses.startTime
        holder.endTime.text = courses.endTime
        holder.location.text = courses.location
        holder.level.text = courses.level
        holder.btn_edit.setOnClickListener {
            val index = Intent(context, AddCourse::class.java)
            index.putExtra("Mode", "E")
            index.putExtra("Id", courses.courseId)
            context.startActivity(index)
        }
    }

    override fun getItemCount(): Int {
        return courseList.size
    }
}